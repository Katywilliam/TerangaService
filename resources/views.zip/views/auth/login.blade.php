@extends('layouts.app')
@section('title', 'Connexion - Teranga Service')
@section('content')

<div style="min-height:80vh; display:flex; align-items:center; justify-content:center; padding:40px 20px; background:linear-gradient(135deg,#F0F4FF 0%,#F0FDF4 100%);">
    <div style="width:100%; max-width:420px;">

        <!-- Logo centré -->
        <div style="text-align:center; margin-bottom:32px;">
            <a href="/" style="display:inline-flex; align-items:center; gap:10px; text-decoration:none;">
                <span style="background:#3A9E3A; padding:10px 13px; border-radius:12px; font-size:20px;">🏠</span>
                <span style="font-size:20px; font-weight:700; color:#1B3A6B;">Teranga <span style="color:#3A9E3A;">Service</span></span>
            </a>
            <p style="color:#6B7280; font-size:14px; margin-top:8px;">Bon retour parmi nous 👋</p>
        </div>

        <div class="card" style="padding:36px; border-top:4px solid #3A9E3A;">
            <h2 style="font-size:22px; font-weight:700; color:#1B3A6B; margin-bottom:24px; text-align:center;">Connexion</h2>

            <form method="POST" action="/login">
                @csrf

                <!-- Email -->
                <div style="margin-bottom:18px;">
                    <label style="display:block; font-size:13px; font-weight:600; color:#374151; margin-bottom:6px;">Adresse email</label>
                    <div style="position:relative;">
                        <span style="position:absolute; left:12px; top:50%; transform:translateY(-50%); font-size:15px;">📧</span>
                        <input type="email" name="email" placeholder="votre@email.com" required
                            style="width:100%; padding:11px 14px 11px 38px; border:1.5px solid #D1D5DB; border-radius:8px; font-size:14px; font-family:'Poppins',sans-serif; color:#374151; background:#FAFAFA; box-sizing:border-box;">
                    </div>
                </div>

                <!-- Mot de passe -->
                <div style="margin-bottom:8px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                        <label style="font-size:13px; font-weight:600; color:#374151;">Mot de passe</label>
                        <a href="/password/reset" style="font-size:12px; color:#3A9E3A; text-decoration:none; font-weight:500;">Mot de passe oublié ?</a>
                    </div>
                    <div style="position:relative;">
                        <span style="position:absolute; left:12px; top:50%; transform:translateY(-50%); font-size:15px;">🔒</span>
                        <input type="password" name="password" placeholder="••••••••" required
                            style="width:100%; padding:11px 14px 11px 38px; border:1.5px solid #D1D5DB; border-radius:8px; font-size:14px; font-family:'Poppins',sans-serif; color:#374151; background:#FAFAFA; box-sizing:border-box;">
                    </div>
                </div>

                <!-- Se souvenir -->
                <div style="display:flex; align-items:center; gap:8px; margin:16px 0 20px;">
                    <input type="checkbox" name="remember" id="remember" style="width:15px; height:15px; accent-color:#3A9E3A; cursor:pointer;">
                    <label for="remember" style="font-size:13px; color:#6B7280; cursor:pointer;">Se souvenir de moi</label>
                </div>

                <!-- Bouton -->
                <button type="submit"
                    style="width:100%; background:#3A9E3A; color:white; padding:13px; border:none; border-radius:8px; font-weight:600; font-size:15px; cursor:pointer; font-family:'Poppins',sans-serif; letter-spacing:0.2px;">
                    Se connecter →
                </button>
            </form>

            <div style="text-align:center; margin-top:20px; padding-top:20px; border-top:1px solid #F3F4F6;">
                <p style="color:#6B7280; font-size:14px;">
                    Pas encore de compte ?
                    <a href="/register" style="color:#3A9E3A; font-weight:600; text-decoration:none; margin-left:4px;">Créer un compte</a>
                </p>
                <p style="color:#6B7280; font-size:13px; margin-top:8px;">
                    Vous êtes prestataire ?
                    <a href="/prestataire/register" style="color:#1B3A6B; font-weight:600; text-decoration:none; margin-left:4px;">Rejoindre ici</a>
                </p>
            </div>
        </div>
    </div>
</div>

@endsection
