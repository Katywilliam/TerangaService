@extends('layouts.app')
@section('title', 'Inscription - Teranga Service')
@section('content')

<div style="min-height:80vh; display:flex; align-items:center; justify-content:center; padding:40px 20px; background:linear-gradient(135deg,#F0F4FF 0%,#F0FDF4 100%);">
    <div style="width:100%; max-width:460px;">

        <!-- Logo centré -->
        <div style="text-align:center; margin-bottom:32px;">
            <a href="/" style="display:inline-flex; align-items:center; gap:10px; text-decoration:none;">
                <span style="background:#3A9E3A; padding:10px 13px; border-radius:12px; font-size:20px;">🏠</span>
                <span style="font-size:20px; font-weight:700; color:#1B3A6B;">Teranga <span style="color:#3A9E3A;">Service</span></span>
            </a>
            <p style="color:#6B7280; font-size:14px; margin-top:8px;">Créez votre compte gratuitement</p>
        </div>

        <div class="card" style="padding:36px; border-top:4px solid #3A9E3A;">
            <h2 style="font-size:22px; font-weight:700; color:#1B3A6B; margin-bottom:24px; text-align:center;">Créer un compte</h2>

            <form method="POST" action="/register">
                @csrf

                <div style="margin-bottom:18px;">
                    <label style="display:block; font-size:13px; font-weight:600; color:#374151; margin-bottom:6px;">Nom complet</label>
                    <div style="position:relative;">
                        <span style="position:absolute; left:12px; top:50%; transform:translateY(-50%); font-size:15px;">👤</span>
                        <input type="text" name="name" placeholder="Votre nom complet" required
                            style="width:100%; padding:11px 14px 11px 38px; border:1.5px solid #D1D5DB; border-radius:8px; font-size:14px; font-family:'Poppins',sans-serif; background:#FAFAFA; box-sizing:border-box;">
                    </div>
                </div>

                <div style="margin-bottom:18px;">
                    <label style="display:block; font-size:13px; font-weight:600; color:#374151; margin-bottom:6px;">Adresse email</label>
                    <div style="position:relative;">
                        <span style="position:absolute; left:12px; top:50%; transform:translateY(-50%); font-size:15px;">📧</span>
                        <input type="email" name="email" placeholder="votre@email.com" required
                            style="width:100%; padding:11px 14px 11px 38px; border:1.5px solid #D1D5DB; border-radius:8px; font-size:14px; font-family:'Poppins',sans-serif; background:#FAFAFA; box-sizing:border-box;">
                    </div>
                </div>

                <div style="margin-bottom:18px;">
                    <label style="display:block; font-size:13px; font-weight:600; color:#374151; margin-bottom:6px;">Téléphone</label>
                    <div style="position:relative;">
                        <span style="position:absolute; left:12px; top:50%; transform:translateY(-50%); font-size:15px;">📱</span>
                        <input type="tel" name="phone" placeholder="77 000 00 00" required
                            style="width:100%; padding:11px 14px 11px 38px; border:1.5px solid #D1D5DB; border-radius:8px; font-size:14px; font-family:'Poppins',sans-serif; background:#FAFAFA; box-sizing:border-box;">
                    </div>
                </div>

                <div style="margin-bottom:18px;">
                    <label style="display:block; font-size:13px; font-weight:600; color:#374151; margin-bottom:6px;">Je suis</label>
                    <select name="role" style="width:100%; padding:11px 14px; border:1.5px solid #D1D5DB; border-radius:8px; font-size:14px; font-family:'Poppins',sans-serif; background:#FAFAFA; cursor:pointer; box-sizing:border-box;">
                        <option value="client">👤 Un client</option>
                        <option value="prestataire">🔧 Un prestataire</option>
                    </select>
                </div>

                <div style="margin-bottom:18px;">
                    <label style="display:block; font-size:13px; font-weight:600; color:#374151; margin-bottom:6px;">Mot de passe</label>
                    <div style="position:relative;">
                        <span style="position:absolute; left:12px; top:50%; transform:translateY(-50%); font-size:15px;">🔒</span>
                        <input type="password" name="password" placeholder="••••••••" required
                            style="width:100%; padding:11px 14px 11px 38px; border:1.5px solid #D1D5DB; border-radius:8px; font-size:14px; font-family:'Poppins',sans-serif; background:#FAFAFA; box-sizing:border-box;">
                    </div>
                </div>

                <div style="margin-bottom:24px;">
                    <label style="display:block; font-size:13px; font-weight:600; color:#374151; margin-bottom:6px;">Confirmer le mot de passe</label>
                    <div style="position:relative;">
                        <span style="position:absolute; left:12px; top:50%; transform:translateY(-50%); font-size:15px;">🔒</span>
                        <input type="password" name="password_confirmation" placeholder="••••••••" required
                            style="width:100%; padding:11px 14px 11px 38px; border:1.5px solid #D1D5DB; border-radius:8px; font-size:14px; font-family:'Poppins',sans-serif; background:#FAFAFA; box-sizing:border-box;">
                    </div>
                </div>

                <button type="submit"
                    style="width:100%; background:#3A9E3A; color:white; padding:13px; border:none; border-radius:8px; font-weight:600; font-size:15px; cursor:pointer; font-family:'Poppins',sans-serif;">
                    Créer mon compte →
                </button>
            </form>

            <div style="text-align:center; margin-top:20px; padding-top:20px; border-top:1px solid #F3F4F6;">
                <p style="color:#6B7280; font-size:14px;">
                    Déjà un compte ?
                    <a href="/login" style="color:#3A9E3A; font-weight:600; text-decoration:none; margin-left:4px;">Se connecter</a>
                </p>
            </div>
        </div>
    </div>
</div>

@endsection
