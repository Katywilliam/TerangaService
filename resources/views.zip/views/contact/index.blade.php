@extends('layouts.app')

@section('title', 'Contact - Teranga Service')

@section('content')
<!-- Hero -->
<div data-aos="fade-down" style="background: linear-gradient(135deg, #1B3A6B, #1B3A6B 90%); color: white; padding: 40px 16px; text-align: center;">
    <div style="max-width: 800px; margin: 0 auto;">
        <h1 style="font-size: clamp(28px, 6vw, 48px); font-weight: bold; margin-bottom: 8px;"><i class="fas fa-phone-alt"></i> Nous contacter</h1>
        <p style="font-size: clamp(14px, 2vw, 20px); color: #D1D5DB;">Une question ? N'hésitez pas à nous écrire.</p>
    </div>
</div>

<!-- Formulaire -->
<div style="padding: 40px 16px; max-width: 1000px; margin: 0 auto;">
    <div style="display: grid; grid-template-columns: 1fr; gap: 24px;">
        
        <!-- Formulaire -->
        <div data-aos="fade-right" class="card" style="padding: 20px; border-top: 4px solid #3A9E3A;">
            <h2 style="font-size: clamp(18px, 2.5vw, 24px); font-weight: bold; color: #1B3A6B; margin-bottom: 16px;"><i class="fas fa-envelope" style="color: #3A9E3A;"></i> Envoyez-nous un message</h2>
            <form>
                <div style="margin-bottom: 12px;">
                    <label style="display: block; color: #374151; font-size: clamp(13px, 1vw, 14px); font-weight: 600; margin-bottom: 4px;"><i class="fas fa-user"></i> Nom complet</label>
                    <input type="text" placeholder="Votre nom" style="width: 100%; padding: 10px; border: 2px solid #E5E7EB; border-radius: 8px; font-size: 14px;">
                </div>
                <div style="margin-bottom: 12px;">
                    <label style="display: block; color: #374151; font-size: clamp(13px, 1vw, 14px); font-weight: 600; margin-bottom: 4px;"><i class="fas fa-envelope"></i> Email</label>
                    <input type="email" placeholder="votre@email.com" style="width: 100%; padding: 10px; border: 2px solid #E5E7EB; border-radius: 8px; font-size: 14px;">
                </div>
                <div style="margin-bottom: 12px;">
                    <label style="display: block; color: #374151; font-size: clamp(13px, 1vw, 14px); font-weight: 600; margin-bottom: 4px;"><i class="fas fa-tag"></i> Sujet</label>
                    <select style="width: 100%; padding: 10px; border: 2px solid #E5E7EB; border-radius: 8px; font-size: 14px;">
                        <option>Question sur un service</option>
                        <option>Problème technique</option>
                        <option>Devenir prestataire</option>
                        <option>Autre</option>
                    </select>
                </div>
                <div style="margin-bottom: 16px;">
                    <label style="display: block; color: #374151; font-size: clamp(13px, 1vw, 14px); font-weight: 600; margin-bottom: 4px;"><i class="fas fa-comment"></i> Message</label>
                    <textarea rows="5" placeholder="Votre message..." style="width: 100%; padding: 10px; border: 2px solid #E5E7EB; border-radius: 8px; font-size: 14px;"></textarea>
                </div>
                <button type="submit" style="width: 100%; background: #3A9E3A; color: white; padding: 12px; border: none; border-radius: 8px; font-weight: 600; font-size: clamp(14px, 1.2vw, 16px); cursor: pointer;"><i class="fas fa-paper-plane"></i> Envoyer</button>
            </form>
        </div>

        <!-- Coordonnées -->
        <div data-aos="fade-left" class="card" style="padding: 20px; border-top: 4px solid #3A9E3A;">
            <h2 style="font-size: clamp(18px, 2.5vw, 24px); font-weight: bold; color: #1B3A6B; margin-bottom: 16px;"><i class="fas fa-map-marker-alt" style="color: #3A9E3A;"></i> Nos coordonnées</h2>
            
            <div style="margin-bottom: 16px;">
                <div style="display: flex; align-items: center; gap: 12px; color: #4B5563; margin-bottom: 10px; font-size: clamp(13px, 1vw, 14px);">
                    <i class="fas fa-envelope" style="font-size: 20px; color: #3A9E3A;"></i>
                    <span>contact@terangaservice.sn</span>
                </div>
                <div style="display: flex; align-items: center; gap: 12px; color: #4B5563; margin-bottom: 10px; font-size: clamp(13px, 1vw, 14px);">
                    <i class="fas fa-phone" style="font-size: 20px; color: #3A9E3A;"></i>
                    <span>+221 77 000 00 00</span>
                </div>
                <div style="display: flex; align-items: center; gap: 12px; color: #4B5563; margin-bottom: 10px; font-size: clamp(13px, 1vw, 14px);">
                    <i class="fas fa-map-marker-alt" style="font-size: 20px; color: #3A9E3A;"></i>
                    <span>Dakar, Sénégal</span>
                </div>
                <div style="display: flex; align-items: center; gap: 12px; color: #4B5563; font-size: clamp(13px, 1vw, 14px);">
                    <i class="fas fa-clock" style="font-size: 20px; color: #3A9E3A;"></i>
                    <span>Lun - Dim : 7h00 - 20h00</span>
                </div>
            </div>

            <!-- Réseaux sociaux -->
            <div style="background: #F3F4F6; padding: 16px; border-radius: 8px; text-align: center;">
                <p style="color: #6B7280; font-size: clamp(13px, 1vw, 14px); font-weight: 600; margin-bottom: 8px;"><i class="fas fa-share-alt"></i> Suivez-nous</p>
                <div style="display: flex; gap: 16px; justify-content: center; flex-wrap: wrap;">
                    <a href="#" style="color: #1B3A6B; font-size: 28px; text-decoration: none;"><i class="fab fa-facebook"></i></a>
                    <a href="#" style="color: #1B3A6B; font-size: 28px; text-decoration: none;"><i class="fab fa-instagram"></i></a>
                    <a href="#" style="color: #1B3A6B; font-size: 28px; text-decoration: none;"><i class="fab fa-twitter"></i></a>
                    <a href="#" style="color: #1B3A6B; font-size: 28px; text-decoration: none;"><i class="fab fa-linkedin"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection