@extends('layouts.app')

@section('title', 'Page non trouvée - Teranga Service')

@section('content')
<div style="padding: 80px 20px; text-align: center; max-width: 600px; margin: 0 auto;">
    <div style="font-size: 80px; margin-bottom: 16px;">🤔</div>
    <h1 style="font-size: 48px; font-weight: bold; color: #1B3A6B;">404</h1>
    <p style="font-size: 20px; color: #6B7280; margin-bottom: 8px;">Oups ! Page non trouvée</p>
    <p style="color: #9CA3AF; margin-bottom: 24px;">La page que vous cherchez n'existe pas ou a été déplacée.</p>
    <a href="/" style="background: #3A9E3A; color: white; padding: 12px 32px; border-radius: 8px; text-decoration: none; display: inline-block;">🏠 Retour à l'accueil</a>
</div>
@endsection